THE SHADOW 901 — Website (Upgraded)
====================================

This is a complete single-page website for your Memphis streetwear store.

HOW TO USE:
1. Download the entire "theshadow901" folder
2. Open "index.html" in any web browser (Chrome, Safari, etc.)
3. It works completely offline

WHAT’S INCLUDED:
- Dark urban streetwear design (black + red + gold)
- Hero with “THE SHADOW 901” + “We got it in us 901”
- Featured products with real photos (Valley of Freedom tee, VICIOUS stacks, Star rhinestone jeans)
- Categories (Tees / Jeans / Hoodies)
- About section with Memphis energy language
- Visit Us section (Wolfchase area • 10AM–8PM)
- Social / Follow Us section
- Fully mobile responsive with working menu
- Clean professional look

NEXT STEPS YOU CAN ASK FOR:
- Add your real Instagram & TikTok links
- Add exact store address / phone number
- Add more product photos
- Create a full Shop page
- Add “New Arrivals” or “Back to School” section
- Change any prices or product names
- Different color scheme

Just tell me what you want next.
